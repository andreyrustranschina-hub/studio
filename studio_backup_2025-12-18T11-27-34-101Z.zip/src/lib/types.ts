export type VideoFile = {
  id: string;
  path: string;
  name: string;
  handle?: FileSystemFileHandle;
};
